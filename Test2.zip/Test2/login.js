const loginFn=(event)=>{
    event.preventDefault()
    let k=document.getElementById("form");
    let h=k.role.value

    if(h==="Master")
    window.location.href="./login1.html"
    else
    window.location.href="./std.html"

}
document.getElementById("submit").addEventListener("click",loginFn)