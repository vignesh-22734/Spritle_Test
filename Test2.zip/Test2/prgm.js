function zero(operation) {
    if (typeof operation === "undefined") return 0;
    else return operation(0);
}

function one(operation) {
    if (typeof operation === "undefined") return 1;
    else return operation(1);
}

function two(operation) {
    if (typeof operation === "undefined") return 2;
    else return operation(2);
}

function three(operation) {
    if (typeof operation === "undefined") return 3;
    else return operation(3);
}

function four(operation) {
    if (typeof operation === "undefined") return 4;
    else return operation(4);
}

function five(operation) {
    if (typeof operation === "undefined") return 5;
    else return operation(5);
}

function six(operation) {
    if (typeof operation === "undefined") return 6;
    else return operation(6);
}

function seven(operation) {
    if (typeof operation === "undefined") return 7;
    else return operation(7);
}

function eight(operation) {
    if (typeof operation === "undefined") return 8;
    else return operation(8);
}

function nine(operation) {
    if (typeof operation === "undefined") return 9;
    else return operation(9);
}

function plus(right) {
    return function(left) {
        return left + right;
    }
}

function minus(right) {
    return function(left) {
        return left - right;
    }
}

function times(right) {
    return function(left) {
        return left * right;
    }
}

function dividedBy(right) {
    return function(left) {
        return Math.floor(left / right);
    }
}
let q1=document.createElement("p")    
q1.innerText='seven(times(five()))'
let q2=document.createElement("p")
q2.innerText=seven(times(five()))

let q3=document.createElement("p")    
q3.innerText='four(plus(nine()))'
let q4=document.createElement("p")
q4.innerText=four(plus(nine()))

let q5=document.createElement("p")    
q5.innerText='eight(minus(three()))'
let q6=document.createElement("p")
q6.innerText=eight(minus(three()))

let q7=document.createElement("p")    
q7.innerText='six(dividedBy(two()))'
let q8=document.createElement("p")
q8.innerText=six(dividedBy(two()))

let q9=document.createElement("p")    
q9.innerText='eight(dividedBy(three()))'
let q10=document.createElement("p")
q10.innerText=eight(dividedBy(three()))




document.getElementById("show").append(q1,q2,q3,q4,q5,q6,q7,q8,q9,q10)

console.log('seven(times(five()))');
console.log(seven(times(five()))); 

console.log('four(plus(nine()))');
console.log(four(plus(nine())));     

console.log('eight(minus(three()))'); 
console.log(eight(minus(three()))); 

console.log('six(dividedBy(two()))'); 
console.log(six(dividedBy(two()))); 

console.log('eight(dividedBy(three()))');  
console.log(eight(dividedBy(three())));    